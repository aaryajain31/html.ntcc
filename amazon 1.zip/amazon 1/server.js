
const express = require('express');
const collectPrices = require('./priceCollector');
const path = require('path');

const app = express();
const PORT = 3000;

app.get('/api/prices', async (req, res) => {
    const url = 'your-url-here';
    const priceHistory = await collectPrices(url);
    res.json(priceHistory);
});

app.use(express.static(path.join(__dirname, 'public')));

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
