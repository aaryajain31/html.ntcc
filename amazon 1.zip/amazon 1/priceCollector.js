
const axios = require('axios');
const cheerio = require('cheerio');

async function collectPrices(url) {
    try {
        const { data } = await axios.get(url);
        const $ = cheerio.load(data);
        
        const prices = []; // Update the selector to match the actual website
        const dates = [];  // Update the selector to match the actual website

        $('your-price-selector').each((index, element) => {
            prices.push(parseFloat($(element).text().replace('$', '')));
        });

        $('your-date-selector').each((index, element) => {
            dates.push($(element).text());
        });

        const priceHistory = dates.map((date, index) => ({
            date,
            price: prices[index],
        }));

        return priceHistory;
    } catch (error) {
        console.error('Error collecting prices:', error);
    }
}

module.exports = collectPrices;
